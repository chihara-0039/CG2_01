#include "Skybox.hlsli"

struct Material {
    float32_t4 color;
};
ConstantBuffer<Material> gMaterial : register(b0);

TextureCube<float32_t4> gTexture : register(t0);
SamplerState gSampler : register(s0);

struct PixelShaderOutput {
    float32_t4 color : SV_TARGET0;
};

PixelShaderOutput main(VertexShaderOutput input) {
    float32_t4 textureColor = gTexture.Sample(gSampler, normalize(input.texcoord));
    PixelShaderOutput output;
    output.color = textureColor * gMaterial.color;
    return output;
}
